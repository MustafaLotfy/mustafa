/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import office.Entities.Group;
import office.Entities.Period;

import office.Entities.Student;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

/**
 *
 * @author Mohamed Abdelgelel
 */
public class DbConnection {
       

    
    
    
     public static int insertStudent(Student s)
    {
        
        try{
            Connection connection = getConnection();
            PreparedStatement insert= connection.prepareStatement("INSERT INTO [Student]([ID],[Name],[Kind] ,[Cost_of_books] ,[Number],[Mail],[Father_number],[Number_of_books] ,[Notes] ,[Whatsapp] ,[Pay],[School],[Number_of_group],[check_student]) VALUES ('"+s.getId()+"','"+s.getName()+"','"+s.getDivision()+"','"+s.getBookPay()+"','"+s.getPhone()+ "','"+s.getEmail()+"','"+s.getParentPhone()+"','"+s.getNumberOfBookTook()+"','"+s.getNotes()+"','"+s.getWhats()+"','"+s.getPay()+"','"+s.getSchool()+"','"+s.getGroupNumber()+"','"+s.isBookChecked()+"')");
int x= insert.executeUpdate();
            System.out.println(x);
        }
       catch(Exception E)
        {
            return 0;
        }
        return 1;
    }
    
   
    public static int insertGroup(Group g)
    {
        
        try{
            Connection connection = getConnection();
            PreparedStatement insert= connection.prepareStatement("INSERT INTO [Groups]([ID],[Start],[Finish],[Date]) VALUES('"+g.getId() +"','"+g.getStart()+"','"+g.getEnd()+"','"+g.getDate()+"')");
          int x= insert.executeUpdate();
            System.out.println(x);
        }
        catch(Exception E)
        {
            return 0;
        }
        return 1;
    }
    
    //changes
    public static boolean insertGroupLesson(Group g)
    {
        
        try{
            Connection connection = getConnection();
            PreparedStatement insert= connection.prepareStatement("INSERT INTO [Group_and_lesson]([ID_group]) VALUES('"+g.getId() +"')");
            
       insert.executeUpdate();
       
            System.out.println("done insert");
            return true;
        }
        catch(Exception E)
        {
            System.out.println(E);
        }
        return false;
    }
    
    
    public static boolean insertLesson(int id,int groupNumber,String date)
    {
        System.out.println(id +" V " + groupNumber);
        try{
            Connection connection = getConnection();
            PreparedStatement insert= connection.prepareStatement("INSERT INTO [Lesson]([ID],[Group_number],[Date]) VALUES ('"+id+"','"+groupNumber+"','"+date+"')");
            
            insert.executeUpdate();
            System.out.println("done insert");
            return true;
        }
        catch(Exception E)
        {
            
            System.out.println(E);
            return false;
        }
    }
    
    //changes
     public static boolean insertAttendence(Student s,int groupAttend)
    {
        
        try{
            Connection connection = getConnection();
            PreparedStatement insert= connection.prepareStatement("INSERT INTO [Attendence]([ID_student],[Group_number],[ID_for_lesson] ,[Group_attend]) VALUES ('"+s.getId()+"','"+s.getGroupNumber()+"','"+s.getPe().getId()+"','"+groupAttend+"')");
            insert.executeUpdate();
            System.out.println("dosssssssssssssssssssssssssssse insert");
            return true;
            
        }
        catch(Exception E)
        {
            System.out.println(E);
            return false;
        }

    }
   
    public static Connection getConnection() throws Exception{
            try{
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:Office.sqlite");
            System.out.println("Connected");
            return conn;
            } catch(Exception e){
                System.out.println(e);

            } 
        return null;
    }
    
       public static ArrayList<Student> selectByGroup(int id) throws Exception
        {
            ArrayList<Student> students= new ArrayList<>();
            Connection connection;
            
                connection = getConnection();
                            PreparedStatement create= connection.prepareStatement("select * from Student where Number_of_group = "+id);
                ResultSet result=create.executeQuery();
                while(result.next())

                              // System.out.println(result.getString("start_d"));
                        students.add(new Student(result.getInt("ID"),result.getInt("Number_of_books"),result.getInt("Pay"),result.getInt("Cost_of_books"),result.getString("Number"),result.getString("Name"),result.getString("Father_number"),result.getString("Kind"),result.getString("whatsapp"),result.getString("Mail"),result.getString("Notes"),result.getInt("Number_of_group"),result.getString("School"),result.getBoolean("check_student")));
                        System.out.println("done");

                         //  System.out.println(gs.get(0).getSTART());
                        
            return students;
        }
       
       public static Group selectGroup(int id) throws Exception
        {
            Group group= null;
            Connection connection;
            
                connection = getConnection();
                            PreparedStatement create= connection.prepareStatement("select * from Groups where ID="+id);
            ResultSet result=create.executeQuery();
            while(result.next())

                          // System.out.println(result.getString("start_d"));
             group= new Group(result.getInt("ID"),result.getInt("Start"),result.getInt("Finish"),result.getString("Date"));
              //System.out.println("done");

                     //  System.out.println(gs.get(0).getSTART());
                 return group;
        }
       
       
      public static Group selectGroupLesson(int id) throws Exception
        {
            Group g = null;
            Connection connection;
            
            connection = getConnection();
            PreparedStatement create= connection.prepareStatement("select * from Group_and_lesson where ID_group="+id);
            ResultSet result=create.executeQuery();
            while(result.next())
                 
               // System.out.println(result.getString("start_d"));
            g= new Group(result.getInt("ID_group"),new Period (result.getInt("ID_lesson")));
            System.out.println("done");
           
          //  System.out.println(gs.get(0).getSTART());
             return g;
        }


       
       
       
       public static void updateGroupLesson(Group g) throws Exception
        {
            Connection connection;
            
                connection = getConnection();
                PreparedStatement update= connection.prepareStatement("UPDATE [Group_and_lesson] SET [ID_lesson] = '"+ g.getPe().getId()+"' WHERE ID_group="+g.getId());
                update.executeUpdate();
                 
                System.out.println("done update");
           
        }
       public static Student selecBytId(int id) throws Exception
        {
            Student s=null;
            Connection connection;
            
            connection = getConnection();
            PreparedStatement create= connection.prepareStatement("select * from Student where Id = "+id);
            ResultSet result=create.executeQuery();
            while(result.next())

            s= new Student(result.getInt("ID"),result.getInt("Number_of_books"),result.getInt("Pay"),result.getInt("Cost_of_books"),result.getString("Number"),result.getString("Name"),result.getString("Father_number"),result.getString("Kind"),result.getString("whatsapp"),result.getString("Mail"),result.getString("Notes"),result.getInt("Number_of_group"),result.getString("School"),Boolean.parseBoolean(result.getString("check_student")));
            System.out.println("done");
           
         // System.out.println(s.isBookChecked());
            return s;
        }
       
  public static Student selecBytName(String name) throws Exception
        {
            Student s=null;
            Connection connection;
            
            connection = getConnection();
            PreparedStatement create= connection.prepareStatement("SELECT * FROM Student where Name LIKE '%"+name+"%'");
            ResultSet result=create.executeQuery();
            while(result.next())

            s= new Student(result.getInt("ID"),result.getInt("Number_of_books"),result.getInt("Pay"),result.getInt("Cost_of_books"),result.getString("Number"),result.getString("Name"),result.getString("Father_number"),result.getString("Kind"),result.getString("whatsapp"),result.getString("Mail"),result.getString("Notes"),result.getInt("Number_of_group"),result.getString("School"),Boolean.parseBoolean(result.getString("check_student")));
            System.out.println("done");
           
         // System.out.println(s.isBookChecked());
            return s;
        }
   public static Student selecByPhone(String phone) throws Exception
        {
            Student s=null;
            Connection connection;
            
            connection = getConnection();
            PreparedStatement create= connection.prepareStatement("SELECT * FROM Student where Number ='"+phone+"'");
            ResultSet result=create.executeQuery();
            while(result.next())

            s= new Student(result.getInt("ID"),result.getInt("Number_of_books"),result.getInt("Pay"),result.getInt("Cost_of_books"),result.getString("Number"),result.getString("Name"),result.getString("Father_number"),result.getString("Kind"),result.getString("whatsapp"),result.getString("Mail"),result.getString("Notes"),result.getInt("Number_of_group"),result.getString("School"),Boolean.parseBoolean(result.getString("check_student")));
            System.out.println("done");
           
         // System.out.println(s.isBookChecked());
            return s;
        }
    public static void updateLessonCost(Period p,int group) throws Exception
        {
            Connection connection;
            
                          connection = getConnection();
                          PreparedStatement update= connection.prepareStatement("UPDATE [Lesson] SET [Cost] = '"+p.getTotalMoney()+"' WHERE ID="+p.getId()+" and Group_number="+group);
                          update.executeUpdate();
                 
         System.out.println("done update");
           
        }
    
    
        public static void updateLessonAttend(Period p,int group) throws Exception
        {
            Connection connection;
            
                          connection = getConnection();
                            PreparedStatement update= connection.prepareStatement("UPDATE [Lesson] SET [Attend_number] = '"+p.getAttendenceNumber()+"' WHERE ID="+p.getId()+" and Group_number="+group);
                           update.executeUpdate();
                 
         System.out.println("done update");
           
        }
        
        
        
        public static void updateLessonAbsence(Period p,int group) throws Exception
        {
            Connection connection;
            
                          connection = getConnection();
                            PreparedStatement update= connection.prepareStatement("UPDATE [Lesson] SET [Absent]  = '"+p.getAbsence()+"' WHERE ID="+p.getId()+" and Group_number="+group);
                           update.executeUpdate();
                 
         System.out.println("done update");
           
        }
        
        
         public static void updateLessonAttendAnotherTime(Period p,int group) throws Exception
        {
            Connection connection;
            
                          connection = getConnection();
                            PreparedStatement update= connection.prepareStatement("UPDATE [Lesson] SET [Attend_another_time]  = '"+p.getAttendInAnotherTime()+"' WHERE ID="+p.getId()+" and Group_number="+group);
                           update.executeUpdate();
                 
         System.out.println("done update");
           
        }
        
         public static void updateLessonPayment(Period p,int group) throws Exception
        {
            Connection connection;
            
                          connection = getConnection();
                            PreparedStatement update= connection.prepareStatement("UPDATE [Lesson] SET [Payments]  = '"+p.getPayment()+"' WHERE ID="+p.getId()+" and Group_number="+group);
                           update.executeUpdate();
                 
         System.out.println("done update");
           
        }
         
         
          public static void updateLessonNotes(Period p,int group) throws Exception
        {
            Connection connection;
            
                          connection = getConnection();
                            PreparedStatement update= connection.prepareStatement("UPDATE [Lesson] SET [Notes]  = '"+p.getNotes()+"' WHERE ID="+p.getId()+" and Group_number="+group);
                           update.executeUpdate();
                 
         System.out.println("done update");
           
        }
          
           public static ArrayList<Period> selectAllLesson(String date) throws Exception
        {
            ArrayList <Period> lessons = new ArrayList<>();
           Period lesson= null;
           Connection connection;
            connection = getConnection();
            PreparedStatement create= connection.prepareStatement("select * from Lesson where Date = '"+date+"'");
            
            ResultSet result=create.executeQuery();
            
            while(result.next()){
                 
               // System.out.println(result.getString("start_d"));
                lessons.add(new Period(result.getInt("Group_number"),result.getInt("Attend_number"),result.getInt("Absent"),result.getInt("Attend_another_time"),result.getInt("Cost"),result.getInt("ID"),result.getInt("Total_student"),result.getString("Date"),result.getString("Notes"),result.getDouble("Payments"),result.getDouble("increase_balance")));
            
            }
            System.out.println("done done done done");
           
          //  System.out.println(gs.get(0).getSTART());
            return lessons;
        }
        public static void updateLessonTotal(Period p,int group) throws Exception
        {
            Connection connection;
            
            connection = getConnection();
            PreparedStatement update= connection.prepareStatement("UPDATE [Lesson] SET [Total_student]  = '"+p.getTotalNumber()+"' WHERE ID="+p.getId()+" and Group_number="+group);
            update.executeUpdate();
                 
         System.out.println("done update");
           
        }
        
        
        
        public static Period selectLesson(int id,int group) throws Exception
        {
           Period lesson= null;
           Connection connection;
            System.out.println("id = "+id+ " Group = "+group);
            connection = getConnection();
            PreparedStatement create= connection.prepareStatement("select * from Lesson where ID = "+id+" and Group_number = "+group);
            
            ResultSet result=create.executeQuery();
            
            while(result.next()){
                 
               // System.out.println(result.getString("start_d"));
                System.out.println("Check5");
                lesson=new Period(result.getInt("Group_number"),result.getInt("Attend_number"),result.getInt("Absent"),result.getInt("Attend_another_time"),result.getInt("Cost"),result.getInt("ID"),result.getInt("Total_student"),result.getString("Date"),result.getString("Notes"),result.getDouble("Payments"),result.getDouble("increase_balance"));
            
            }
            System.out.println("done done done done");
           
          //  System.out.println(gs.get(0).getSTART());
            return lesson;
        }
        
        
         public static ArrayList<Student> selecAttendance(int id) throws Exception
        {
           ArrayList<Student> students  = new ArrayList<>();
            Connection connection;
            
            connection = getConnection();
            PreparedStatement create= connection.prepareStatement("select * from Attendence where ID_student = "+id);
            ResultSet result=create.executeQuery();
            while(result.next())
                 
            // System.out.println(result.getString("start_d"));
            students.add( new Student(result.getInt("ID_student"),result.getInt("Group_number"),new Period(result.getInt("ID_for_lesson"),result.getInt("total_degree"),result.getDouble("student_degree")),result.getInt("Group_attend")));
            System.out.println("done");
           
            //  System.out.println(gs.get(0).getSTART());
            return students;
        }
         
         
         public static Group selectGroupTotal(int id) throws Exception {
                Group group = null;
                Connection connection;

                connection = getConnection();
                PreparedStatement create = connection.prepareStatement("select Total_student from Groups where ID=" + id);
                ResultSet result = create.executeQuery();
                while (result.next()) // System.out.println(result.getString("start_d"));
                {
                    group=new Group(result.getInt("Total_student"));
                }
             //   System.out.println(id + "        "+ group.getTotalStudent());
             //   System.out.println("done  BN");

                //  System.out.println(gs.get(0).getSTART());
                return group;
         }
         
          public static void updateGroup( Group g) throws Exception {
        Connection connection;

        connection = getConnection();
        PreparedStatement update = connection.prepareStatement("UPDATE [Groups] SET [Total_student] = '" + g.getTotalStudent() + "' WHERE ID=" + g.getId());
        update.executeUpdate();

        System.out.println("done update");

    }
          
          
    public static int updateAttendence(Student s) throws Exception {
        int check=0;
        Connection connection;
        System.out.println(s.getPe().getTotalDegree() + "   "+s.getPe().getStudentDegree()+"   "+ s.getId()+ "    "+ s.getPe().getId());
        connection = getConnection();
        PreparedStatement update = connection.prepareStatement("UPDATE [Attendence] SET [total_degree] = '" + s.getPe().getTotalDegree() + "',[student_degree] = '"+s.getPe().getStudentDegree()+"' WHERE ID_student=" + s.getId()+" AND ID_for_lesson="+s.getPe().getId());
        
        check=update.executeUpdate();
        
        return check;
       // System.out.println("done update");
    }
    
    
    public static ArrayList<Student> selecAttendanceSimple(int id) throws Exception {
        ArrayList<Student> students = new ArrayList<>();
        Connection connection;

        connection = getConnection();
        PreparedStatement create = connection.prepareStatement("select * from Attendence where ID_student = " + id + " ORDER BY ID_for_lesson DESC LIMIT 2");
        ResultSet result = create.executeQuery();
        while (result.next()) // System.out.println(result.getString("start_d"));
        {
            students.add(new Student(result.getInt("ID_student"), result.getInt("Group_number"), new Period(result.getInt("ID_for_lesson")), result.getInt("Group_attend")));
        }
        System.out.println("done");

        //  System.out.println(gs.get(0).getSTART());
        return students;
    } 
    public static void updateAttendence(Student s , int id) throws Exception {
        Connection connection;

        connection = getConnection();
        PreparedStatement update = connection.prepareStatement("UPDATE [Attendence] SET [ID_student]  = '" + id + "' WHERE ID_student=" +s.getId());
        update.executeUpdate();

        System.out.println("done update");

    }
     public static int updateStudent( Student s ,int id) {
        try {
            Connection connection;
            
            connection = getConnection();
            PreparedStatement update = connection.prepareStatement("UPDATE [Student] SET [Number_of_group] = '" + s.getGroupNumber() + "',[ID] = '"+id+"' WHERE ID=" +s.getId());
            update.executeUpdate();
            
            System.out.println("done update");
        } catch (Exception ex) {
            return 0;
        }
        return 1;
    }
     public static int updateStudentInfo( Student s ) {
        try {
            Connection connection;
            
            connection = getConnection();
            PreparedStatement update = connection.prepareStatement("UPDATE [Student] SET [Name] = '" + s.getName() + "',[Kind] = '"+s.getDivision()+"',[Cost_of_books] = '"+s.getBookPay()+"',[Number] = '"+s.getPhone()+"' ,[Father_number] = '"+s.getParentPhone()+"' ,[Number_of_books] = '"+s.getNumberOfBookTook()+"' ,[Notes] = '"+s.getNotes()+"' ,[School] = '"+s.getSchool()+"' ,[Pay] = '"+s.getPay()+"',[Whatsapp] = '"+s.getWhats()+"',[Mail] = '"+s.getEmail()+"',[check_student] = '"+s.isBookChecked()+"' WHERE ID=" +s.getId());
            update.executeUpdate();
            
            System.out.println("done update");
        } catch (Exception ex) {
            return 0;
        }
return 1;
    }
     public static void DeleteStudent(int id) throws Exception
        {
            Connection connection;
            
            connection = getConnection();
            PreparedStatement delete= connection.prepareStatement("DELETE FROM [Student] WHERE ID="+id);
            delete.executeUpdate();
                 
         System.out.println("done delete");
           
        }
          public static void DeleteAttendence(int id) throws Exception
        {
            Connection connection;
            
            connection = getConnection();
            PreparedStatement delete= connection.prepareStatement("DELETE FROM [Attendence] WHERE ID_student="+id);
            delete.executeUpdate();
                 
         System.out.println("done delete");
           
        }
          
          
     public static ArrayList<Student> selectBycheck(boolean check) throws Exception
        {
            ArrayList<Student> students= new ArrayList<>();
            Connection connection;
            
                connection = getConnection();
                            PreparedStatement create= connection.prepareStatement("select * from Student where check_student = '"+check+"'");
                ResultSet result=create.executeQuery();
                while(result.next())

                              // System.out.println(result.getString("start_d"));
                        students.add(new Student(result.getInt("ID"),result.getInt("Number_of_books"),result.getInt("Pay"),result.getInt("Cost_of_books"),result.getString("Number"),result.getString("Name"),result.getString("Father_number"),result.getString("Kind"),result.getString("whatsapp"),result.getString("Mail"),result.getString("Notes"),result.getInt("Number_of_group"),result.getString("School"),Boolean.parseBoolean(result.getString("check_student"))));
                        System.out.println("done");

                         //  System.out.println(gs.get(0).getSTART());
                        
            return students;
        }
        
     
      public static int updateIncreaseBooks ( double increase ) {
        try {
            Connection connection;
            
            connection = getConnection();
            PreparedStatement update = connection.prepareStatement("UPDATE [Books] SET [increase_books] = '" + increase+ "' WHERE ID=" +1);
            update.executeUpdate();
            
            System.out.println("done update");
        } catch (Exception ex) {
            return 0;
        }
        return 1;
    }
      public static int updatedecreaseBooks ( double decrease ) {
        try {
            Connection connection;
            
            connection = getConnection();
            PreparedStatement update = connection.prepareStatement("UPDATE [Books] SET [decrease_books] = '" + decrease+ "' WHERE ID=" +1);
            update.executeUpdate();
            
            System.out.println("done update");
        } catch (Exception ex) {
            return 0;
        }
return 1;
    }
    
      
      
     public static double selectIncreaseBook() throws Exception
        {
            double cost = 0;
            Connection connection;
            
                connection = getConnection();
                            PreparedStatement create= connection.prepareStatement("select increase_books from Books where Id=1");
            ResultSet result=create.executeQuery();
            while(result.next())
            cost = result.getDouble("increase_books");
                                      // System.out.println(result.getString("start_d"));
                          //System.out.println("done");

                                 //  System.out.println(gs.get(0).getSTART());
                 return cost;
        }
           public static double selectDecreaseBook() throws Exception
        {
            double cost = 0;
            Connection connection;
            
                connection = getConnection();
                            PreparedStatement create= connection.prepareStatement("select decrease_books from Books where Id=1");
            ResultSet result=create.executeQuery();
            while(result.next())
               cost = result.getDouble("decrease_books");
                          // System.out.println(result.getString("start_d"));
              //System.out.println("done");

                     //  System.out.println(gs.get(0).getSTART());
                 return cost;
        }  
      
    public static void main(String[] args) throws Exception {

        Student s =selecBytName("mohamed");
        System.out.println(s.getBookPay());
        }
}