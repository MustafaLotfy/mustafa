<?php
include_once 'dbh.inc.php';
date_default_timezone_set('Africa/Cairo');
if(isset($_POST['signup-submit'])){

    //get the data from the front
    $first_name=mysqli_real_escape_string($conn,$_POST['first_name']);
    $last_name=mysqli_real_escape_string($conn,$_POST['last_name']);
    $password=mysqli_real_escape_string($conn,$_POST['password']);
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $birth_date=mysqli_real_escape_string($conn,$_POST['birth_date']);
    $date=date('Y-m-d H:i:s');
    $country_name=mysqli_real_escape_string($conn,$_POST['country_name']);
    $address=mysqli_real_escape_string($conn,$_POST['address']);
    $phone_number=mysqli_real_escape_string($conn,$_POST['phone_number']);
    if(empty($address))$address=NULL;

    //check if there's empty fields
    if(empty($first_name)||empty($last_name)||empty($email)
        ||empty($password)||empty($birth_date)||empty($phone_number)||empty($country_name)){
      
        header("Location: ../signup.php?signup=empty");
        exit();
    }
    //check if there's invalid data
    elseif(!preg_match("/^[a-zA-Z]*$/",$first_name)||
            !preg_match("/^[a-zA-Z]*$/",$last_name)||
            !is_numeric($phone_number)||
            !filter_var($email,FILTER_VALIDATE_EMAIL)||
            !preg_match("/^[a-zA-Z]*$/",$country_name)||
            !preg_match("/^[a-zA-Z0-9]*$/",$password)){
            header("Location: ../signup.php?signup=invalid");
            exit();}
    else {
        //check if there's similar exists
        $sql_email="select email from users where email='$email';";
        $sql_phone="select phone_number from users where phone_number='$phone_number';";
        $result_email=mysqli_query($conn,$sql_email);
        $result_phone=mysqli_query($conn,$sql_phone);
        $result_email_number=mysqli_num_rows($result_email);
        $result_phone_number=mysqli_num_rows($result_phone);
        if($result_email_number>0||$result_phone_number>0){
            if($result_email_number>0){
                header("Location: ../signup.php?signup=existsE");
                exit();}
            else {
                header("Location: ../signup.php?signup=existsP");
                exit();}
        }
        else {
            //password encryption
            $hashed_password=password_hash($password,PASSWORD_DEFAULT);
            //inseting data into the table
            $sql="insert into users(first_name,last_name,email,password,phone_number,address,birth_date,registeration_date,country_name)
                  values ('$first_name','$last_name','$email','$hashed_password','$phone_number','$address','$birth_date','$date','$country_name');";
            mysqli_query($conn,$sql);
            header("Location: ../signup.php?signup=success");
            exit();
        }
    }

}
else {

    header("Location: ../signup.php?signup=error");
    exit();
}