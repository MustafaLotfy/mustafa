<?php
date_default_timezone_set('Asia/Dubai');
if(isset($_POST['signup-submit-f'])){
    include_once 'dbh.inc.php';
    $name=mysqli_real_escape_string($conn,$_POST['name']);
    $password=mysqli_real_escape_string($conn,$_POST['password']);
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $starting_date=mysqli_real_escape_string($conn,$_POST['starting_date']);
    $date=date('Y-m-d H:i:s');
    $country_name=mysqli_real_escape_string($conn,$_POST['country_name']);
    $address=mysqli_real_escape_string($conn,$_POST['address']);
    $phone_number=mysqli_real_escape_string($conn,$_POST['phone_number']);
    if(empty($address))$address=NULL;
    if(empty($name)||empty($email)||empty($password)||
        empty($starting_date)||empty($phone_number)||empty($country_name)){
        header("Location: ../signup.php?signup=empty");
        exit();
    }
    elseif(!preg_match("/^[a-zA-Z]*$/",$name)||
            !is_numeric($phone_number)||
            !filter_var($email,FILTER_VALIDATE_EMAIL)||
            !preg_match("/^[a-zA-Z]*$/",$country_name)||
            !preg_match("/^[a-zA-Z0-9]*$/",$password)){
            header("Location: ../signup.php?signup=invalid");
            exit();}
    else {
        $sql1="select email from users where email='$email';";
        $sql2="select phone_number from users where phone_number='$phone_number';";
        $result1=mysqli_query($conn,$sql1);
        $result2=mysqli_query($conn,$sql2);
        $result_number1=mysqli_num_rows($result1);
        $result_number2=mysqli_num_rows($result2);
        $sql3="select email from families where email='$email';";
        $sql4="select phone_number from families where phone_number='$phone_number';";
        $result3=mysqli_query($conn,$sql3);
        $result4=mysqli_query($conn,$sql4);
        $result_number3=mysqli_num_rows($result3);
        $result_number4=mysqli_num_rows($result4);
        $sql5="select email from admins where email='$email';";
        $sql6="select phone_number from admins where phone_number='$phone_number';";
        $result5=mysqli_query($conn,$sql5);
        $result6=mysqli_query($conn,$sql6);
        $result_number5=mysqli_num_rows($result5);
        $result_number6=mysqli_num_rows($result6);
        if($result_number1>0||$result_number2>0||$result_number3>0||$result_number4>0||$result_number5>0||$result_number6>0){
            if($result_number1>0||$result_number3>0||$result_number5>0){
                header("Location: ../signup.php?signup=exists1");
                exit();}
            else {
                header("Location: ../signup.php?signup=exists2");
                exit();}
        }
        else {
            $hashed_password=password_hash($password,PASSWORD_DEFAULT);
            $sql="insert into families(name,email,password,phone_number,address,starting_date,registeration_date,country_name)
                  values ('$name','$email','$password','$phone_number','$address','$starting_date','$date','$country_name');";
            mysqli_query($conn,$sql);
            header("Location: ../signup.php?signup=success");
            exit();
        }
    }

}
else {

    header("Location: ../signup.php");
    exit();
}