<?php
include_once 'dbh.inc.php';
session_start();
date_default_timezone_set('Africa/Cairo');
if(isset($_POST['edit-submit'])& isset($_SESSION['id'])) {

    //get the data from the front
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $country_name = mysqli_real_escape_string($conn, $_POST['country_name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $password_conformation = mysqli_real_escape_string($conn, $_POST['password_conformation']);
    //check if there's invalid data
    if ((!preg_match("/^[a-zA-Z]*$/", $name) & !empty($name)) ||
        (!is_numeric($phone_number) & !empty($phone_number)) ||
        (!filter_var($email, FILTER_VALIDATE_EMAIL) & !empty($email)) ||
        (!preg_match("/^[a-zA-Z]*$/", $country_name) & !empty($country_name)) ||
        (!preg_match("/^[a-zA-Z0-9]*$/", $password) & !empty($password))
    ) {
        header("Location: ../profile.php?profile=invalid");
        exit();
    } else {
        $sql = "select password from families where id='" . $_SESSION['id'] . "'";
        $result = mysqli_query($conn, $sql);
        $result_number = mysqli_num_rows($result);
        if ($result_number <= 0) {
            header("Location: ../profile.php?profile=unknown");
            exit();
        } else {
            if ($row = mysqli_fetch_assoc($result)) {
                //De-hashing password
                if (!password_verify($password_conformation, $row['password'])) {header("Location: ../profile.php?profile=mismatch");exit();}
                else{
                    $sql_email = "select email from families where email='$email' and id!='" . $_SESSION['id'] . "';";
                    $result_email = mysqli_query($conn, $sql_email);
                    $result_email_number = mysqli_num_rows($result_email);
                    $sql_email_2 = "select email from users where email='$email' ;";
                    $result_email_2 = mysqli_query($conn, $sql_email_2);
                    $result_email_number_2 = mysqli_num_rows($result_email_2);
                    if ($result_email_number > 0 || $result_email_number_2>0) {header("Location: ../profile.php?profile=exists");exit();}
                    else {
                        if (!empty($first_name)) {
                            $sql = "update families set first_name='$first_name' where id='" . $_SESSION['id'] . "';";
                            mysqli_query($conn, $sql);
                        }

                        if (!empty($email)) {
                            $sql = "update families set email='$email' where id='" . $_SESSION['id'] . "';";
                            mysqli_query($conn, $sql);
                        }

                        if (!empty($last_name)) {
                            $sql = "update families set last_name='$last_name' where id='" . $_SESSION['id'] . "';";
                            mysqli_query($conn, $sql);
                        }

                        if (!empty($password)) {
                            $password=password_hash($password,PASSWORD_DEFAULT);
                            $sql = "update families set password='$password' where id='" . $_SESSION['id'] . "';";
                            mysqli_query($conn, $sql);
                        }

                        if (!empty($address)) {
                            $sql = "update families set address='$address' where id='" . $_SESSION['id'] . "';";
                            mysqli_query($conn, $sql);
                        }

                        if (!empty($country_name)) {
                            $sql = "update families set country_name='$country_name' where id='" . $_SESSION['id'] . "';";
                            mysqli_query($conn, $sql);
                        }

                        if (!empty($phone_number)) {
                            $sql = "update families set phone_number='$phone_number' where id='" . $_SESSION['id'] . "';";
                            mysqli_query($conn, $sql);
                        }

                        header("Location: ../profile.php?update=success");exit();
                    }
                }
            }
        }
    }
}
else {header("Location: ../profile.php?profile=error");exit();}