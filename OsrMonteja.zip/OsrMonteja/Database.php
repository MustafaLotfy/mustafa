<?php
include 'User.php';
include './Admin.php';
include './Familiy.php';
    include './Product.php';
    //session_start();
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Database
 *
 * @author mohamed
 */
class  Database {
    public static function conn()
    {
        return $conn=mysqli_connect("localhost","root","","osrmntja");

    }

    public static function connect()
    {
    try {
    $dsn='mysql:host=localhost;dbname=osrmntja';
     $username='root';
     $password='';
        $options=array(PDO::MYSQL_ATTR_INIT_COMMAND=>'SET NAMES utf8',);
         $con = new PDO($dsn, $username, $password, $options);
} catch (Exception $exc) {

    }
    return $con;
}
public static function selectUser ($email,$pass) 
{
    $user = new User();
    try {
        $con= Database::connect();
    $query=$con->prepare("SELECT id, email, password FROM users WHERE email = '$email' AND password = '$pass'");
    $query->execute();
    
    //$query->execute(array($email,$pass));
    } catch (Exception $ex) {
            echo $exc->getTraceAsString();

    }
    if($query->rowCount()>0)
    {
while($result = $query->fetch()){
       $user->setId($result['id']) ;
       $user->setEmail($result['email']);
       $user->setPassword($result['password']);
}
return $user;

    }
 else {
    return NULL;    
    }

}
public static function selectFamiliy ($email,$pass) 
{
    $user = new Familiy();
    try {
        $con= Database::connect();
    $query=$con->prepare("SELECT id, email, password FROM families WHERE email = '$email' AND password = '$pass'");
    $query->execute();
    
    //$query->execute(array($email,$pass));
    } catch (Exception $ex) {
            echo $exc->getTraceAsString();

    }
    if($query->rowCount()>0)
    {
while($result = $query->fetch()){
       $user->setId($result['id']) ;
       $user->setEmail($result['email']);
       $user->setPassword($result['password']);
}
return $user;

    }
 else {
    return NULL;    
    }

}
public static function selectAdmin ($email,$pass) 
{
    $user = new Admin();
    try {
        $con= Database::connect();
    $query=$con->prepare("SELECT id, email, password FROM admins WHERE email = '$email' AND password = '$pass'");
    $query->execute();
    
    //$query->execute(array($email,$pass));
    } catch (Exception $ex) {
            echo $exc->getTraceAsString();

    }
    if($query->rowCount()>0)
    {
while($result = $query->fetch()){
       $user->setId($result['id']) ;
       $user->setEmail($result['email']);
       $user->setPassword($result['password']);
}
return $user;

    }
 else {
    return NULL;    
    }
    

}
public static function selectProducts ($id) 
{
    $products = array();
    try {
        $con= Database::connect();
    $query=$con->prepare("SELECT id, name, price, information, date, photo, video FROM Products WHERE famiy_id = '$id'");
    $query->execute();
    
    //$query->execute(array($email,$pass));
    } catch (Exception $ex) {
            echo $exc->getTraceAsString();

    }
    if($query->rowCount()>0)
    {
       while($result = $query->fetch()){
            $product  = new Product();
           
       $product->setId($result['id']) ;
       $product->setName($result['name']);
       $product->setPrice($result['price']);
       $product->setDate($result['date']);
       array_push($products, $product);
}

return $products;

    }
 else {
    return NULL;    
    }
    

}
public static function insertProduct($name,$description,$price,$photo,$video,$id,$date)
{
   
            $con= Database::connect();
                $query=$con->prepare("INSERT INTO `products` (`name`, `price`, `information`, `date`, `photo`, `video`, `family_id`) VALUES ('$name', '$price', '$description','$date', '$photo', '$video', '$id')");


                $result=$query->execute();
                echo $result;
}
public static function check_email_existance($email)
{
 $sql_email="select email from users where email='$email';";
 $result_email=mysqli_query(Database::conn(),$sql_email);
  $result_email_number=mysqli_num_rows($result_email);
  $sql_email_1="select email from families where email='$email';";
 $result_email_1=mysqli_query(Database::conn(),$sql_email_1);
  $result_email_number_1=mysqli_num_rows($result_email_1);
  return( $result_email_number>0 || $result_email_number_1>0);
}

public static function insertUser($first_name,$last_name,$email,$password,$phone_number,$address,$birth_date,$date,$country_name)
{
    $sql="insert into users(first_name,last_name,email,password,phone_number,address,birth_date,registeration_date,country_name)
                  values ('$first_name','$last_name','$email','$password','$phone_number','$address','$birth_date','$date','$country_name');";
            mysqli_query(Database::conn(),$sql);
}
public static function insertFamily($name,$email,$password,$phone_number,$address,$starting_date,$date,$country_name)
{
   $sql="insert into families(name,email,password,phone_number,address,starting_date,registeration_date,country_name)
                  values ('$name','$email','$password','$phone_number','$address','$starting_date','$date','$country_name');";
            mysqli_query(Database::conn(),$sql);
}
public static function checkPassword_user($password_conformation)
{
    $sql = "select password from users where id='" . $_SESSION['id'] . "'";
        $result = mysqli_query(Database::conn(), $sql);
        $result_number = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);
        return password_verify($password_conformation, $row['password']);

}
public static function checkPassword_family($password_conformation)
{
    $sql = "select password from families where id='" . $_SESSION['id'] . "'";
    $result = mysqli_query(Database::conn(), $sql);
    $result_number = mysqli_num_rows($result);
    $row = mysqli_fetch_assoc($result);
    return password_verify($password_conformation, $row['password']);
}
public static function upload_photo_user($file_tmp_name,$file_new_name){
    $_SESSION['photo']=$file_new_name;
    move_uploaded_file($file_tmp_name,'../images/'.$file_new_name.'.jpg');
    $sql = "update users set photo='$file_new_name' where id='" . $_SESSION['id'] . "';";
    mysqli_query(Database::conn(), $sql);
}
    public static function upload_photo_family($file_tmp_name,$file_new_name){
        $_SESSION['photo']=$file_new_name;
        move_uploaded_file($file_tmp_name,'../images/'.$file_new_name.'.jpg');
        $sql = "update users set photo='$file_new_name' where id='" . $_SESSION['id'] . "';";
        mysqli_query(Database::conn(), $sql);
    }
    public static function update_user($first_name,$last_name,$email,$password,$address,$country_name,$phone_number){
        if (!empty($first_name)) {
            $sql = "update users set first_name='$first_name' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($email)) {
            $sql = "update users set email='$email' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($last_name)) {
            $sql = "update users set last_name='$last_name' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($password)) {
            $password=password_hash($password,PASSWORD_DEFAULT);
            $sql = "update users set password='$password' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($address)) {
            $sql = "update users set address='$address' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($country_name)) {
            $sql = "update users set country_name='$country_name' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($phone_number)) {
            $sql = "update users set phone_number='$phone_number' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

    }

    public static function update_family($name,$email,$password,$address,$country_name,$phone_number){
        if (!empty($name)) {
            $sql = "update users set first_name='$name' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($email)) {
            $sql = "update users set email='$email' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }


        if (!empty($password)) {
            $password=password_hash($password,PASSWORD_DEFAULT);
            $sql = "update users set password='$password' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($address)) {
            $sql = "update users set address='$address' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($country_name)) {
            $sql = "update users set country_name='$country_name' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

        if (!empty($phone_number)) {
            $sql = "update users set phone_number='$phone_number' where id='" . $_SESSION['id'] . "';";
            mysqli_query(Database::conn(), $sql);
        }

    }
    public static function check_email_existance_family($email)
    {
        $sql_email="select email from users where email='$email';";
        $result_email=mysqli_query(Database::conn(),$sql_email);
        $result_email_number=mysqli_num_rows($result_email);
        $sql_email_1="select email from families where email='$email' and id!='".$_SESSION['id']."';";
        $result_email_1=mysqli_query(Database::conn(),$sql_email_1);
        $result_email_number_1=mysqli_num_rows($result_email_1);
        return( $result_email_number>0 || $result_email_number_1>0);
    }

    public static function check_email_existance_user($email)
    {
        $sql_email="select email from users where email='$email' and id!='".$_SESSION['id']."';";
        $result_email=mysqli_query(Database::conn(),$sql_email);
        $result_email_number=mysqli_num_rows($result_email);
        $sql_email_1="select email from families where email='$email' ;";
        $result_email_1=mysqli_query(Database::conn(),$sql_email_1);
        $result_email_number_1=mysqli_num_rows($result_email_1);
        return( $result_email_number>0 || $result_email_number_1>0);
    }

}