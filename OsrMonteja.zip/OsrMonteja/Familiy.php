<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Familiy
 *
 * @author mohamed
 */
class Familiy extends Person {
    //put your code here
        private $address;
        private $startDate;
        private $phone;
        function getAddress() {
            return $this->address;
        }

        function getStartDate() {
            return $this->startDate;
        }

        function getPhone() {
            return $this->phone;
        }
        function setAddress($address) {
            $this->address = $address;
        }

        function setStartDate($startDate) {
            $this->startDate = $startDate;
        }

        function setPhone($phone) {
            $this->phone = $phone;
        }



}
