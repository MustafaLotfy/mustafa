<?php
include 'Database.php';

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PersonController
 *
 * @author mohamed
 */
class PersonController {
    public static function login($email,$pass)
    {
        $person= new Person();
        if(Database::selectUser($email, $pass)!= NULL)
        {
                $person=Database::selectUser($email, $pass);
                                        return $person;
        }
                elseif (Database::selectFamiliy($email, $pass)!= NULL) {
                                $person=Database::selectFamiliy($email, $pass);
                                return $person;

            }
            elseif (Database::selectAdmin($email, $pass)!= NULL) {
                                            $person=Database::selectAdmin($email, $pass);
                                return $person;

        }
 else {
     return null;
 }
        
    }
    
    
}
