<?php
//session_start();

include './FamilyController.php';
 //$familyId=$_SESSION['id'];
if (isset($_POST['upload'])) {
    $image = $_FILES['image']['name'];
        $video = $_FILES['video']['name'];

    $target = "../products/images/" . basename($_FILES['image']['name']);
    $target2= "../products/videos/" . basename($_FILES['video']['name']);
    if ( move_uploaded_file($_FILES['video']['tmp_name'], $target2)&&move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
     
        $name=$_POST['name'];
        $description= $_POST['description'];
        $price =$_POST['price'];
       
        FamilyController::addProduct($name, $description, $price, $image, $video, 1);
        
    } else {
        echo 'fail';
    }
}
?>

<!--
<form method="post" action="myworks.php" enctype="multipart/form-data">
    <input type="file" name="image"/>
    <input type="file" name="video" />

    <br/>
    <input type="text" name="name" placeholder="enter product name"/>
    <textarea name="description" rows="4" placeholder="descripe the product"></textarea>
    <br/>

    <input type="text" name="price" placeholder="enter price"/>
    <br/>

    <input type="submit" value="post" name="upload"/>
    <br/>

</form>
-->


