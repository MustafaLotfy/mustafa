<?php

include 'PersonController.php';
session_start();

if($_SERVER['REQUEST_METHOD']=='POST')
{

    $email=$_POST['email'];
    $pass=$_POST['password'];
     $user=  PersonController::login($email,$pass);
if($user!=null)
{
    $_SESSION['id']=$user->getId();
    include 'signup.php';
?>
    

<?php


}
 else {
    echo 'email or pass is incorrect';
    //header("Location: login.php");

}
    
}

?>
<!--
<form action="login.php" method="POST">
        <h4>login</h4>
        <input type="text" name="email" placeholder="enter your email"/>
        <input type="password" name="pass" placeholder="enter your password"/>
        <input type="submit" value="login"/>
    </form>
-->