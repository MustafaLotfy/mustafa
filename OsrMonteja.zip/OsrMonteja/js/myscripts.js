/*(function($){"use strict";$(window).on("load",function(){$(".loader").fadeOut("slow")});$(window).on("load",function(){$(".loader-wrapper").slideUp("slow")});

             <!-- Start Loading page -->
        <div class="loader">
            <div class="loader-wrapper center">
                من فضلك إنتظر قليلا
            </div>
        </div>
        <!-- End Loading page -->
*/