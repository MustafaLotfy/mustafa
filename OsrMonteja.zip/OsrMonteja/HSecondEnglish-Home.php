
<!DOCTYPE html>
<html>
    <head>
        <title>Roductive Families</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel='stylesheet' href="css/w3.css"/>
        <link rel='stylesheet' href="css/WebCSs.css"/>
        <link rel='stylesheet' href="css/Heng-Home.css"/>
        <link href="https://fonts.googleapis.com/css?family=Berkshire+Swash" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Timmana" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="icon" href="images/soft.png">
        <style>
            html,body,h1,h2,h3,h4,h5,h6 {/*font-family: 'Berkshire Swash', cursive;*/font-family: 'Timmana', sans-serif;}
            body{
                background: #c0c0c0 url("images/New.jpg");
				
            }
        </style>
    </head>
    <body>
        <!----------------------Page Container--------------------------->
        <div class="w3-container w3-margin-top">
            <!------Page Card------>
            <div class="w3-white w3-text-grey w3-card-2 w3-round-large" style="background-image: url(images/White-Background.jpg) !important">
 			               
                <!------Card Container------>
              <div class="w3-container w3-padding-16">
                    <!-------Page Logo------->
                    <div class="w3-third" >
                        <div class="w3-container w3-spin w3-center " style="animation-duration:8s">
                            <img class ="w3-padding-16" src="images/NewLogo1.png" width="40%" alt="logo" >
                        </div>
                    </div>
                    
                    <!--------------Start Ads---------------->
                 <div class="w3-padding w3-twothird">
						 <!-------- Ads Banner ---------->
						<div class="" style="height:120px; ">
							<div class="w3-container w3-panel w3-blue w3-card-2 w3-round-large">
								<h2 class="w3-center w3-text-white w3-padding-32">Ads By Google Here...</h2>
							</div>
						</div>
                  </div>
                            
            		  <!---------------Ads Banner--------------->

                </div>
                <br>
                <br>
                <!--------End Header Card Container--------->
                <!--
                <div class="navbar">
                    <div class="container">
                        <h2>Osr<span>Montega</span></h2>
                        <ul>
                            <li class="active"><a href="#">Home</a></li>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Skills</a></li>
                            <li><a href="#">Projects</a></li>
                            <li><a href="#">portofolio</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                </div> -->
                 <!--------start Header NavBar--------->
               
                
                <div>    
                     
                   <div class=" topnav" id="myTopnav">
                     
                          
                          <a href="#">Home</a>
                          <a href="#">News</a>
                          <a href="HAdd-Product.php">Add Product</a>
                          <a >Logout</a>
                          
                          <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
                  </div>
                  
                  
                   <div  style="display:none;">    
                     
                   <div class=" topnav" id="myTopnav">
                     
                          <h2 class="a7a">Osr<span>Montega</span></h2>
                           <!--------Start Login form--------->
                          <form method='post' action='login.php'>
                            <input type='text' name='email' placeholder='E-mail'>
                            <input type='password' name='password' placeholder='password'>
                            <input class="button"  type="submit" value="login"/>
                          </form>
                       <!--------End Login form--------->
                          <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
                  </div>
                  
                </div>
                </div>
                <!--------End Header NavBar--------->
                
                
                <div class="w3-row-padding w3-padding-16">
                   
                   <!---------------------Left Ads----------------------------->
                   <div class="w3-quarter w3-padding-16" >
                        <div class=" w3-text-blue w3-card-2 w3-round-large">
                            <div class="w3-container" >
                                <div class="w3-row w3-panel w3-center w3-leftbar w3-rightbar w3-serif">
                                   
                                         <h1 class="w3-col s12 m0 l12" style="font-size: 24px;"><b><i class="fa fa-buysellads w3-margin-right w3-xxlarge w3-text-blue"></i></b></h1>
                                    
                                </div> 

                              
                                 <img src="images/Sprites.jpg"style="width:100%; height:100%; ">
                            </div>
							<br/>
                        </div>
                       
                    </div>
                    
                   
                    
                    <!--------------------End Left Side--------------------------->

                   
                </div>
            </div>
            <!----------Page Container End---------->
        </div>
        <!---------------------End the first Card-------------------->
        
        
        <!---------------------Start bottom Advertisement------------>
        <div class="w3-container w3-padding-16">
                    <!-------- Ads Banner ---------->
                    <div class="" style="height:120px; ">
                        <div class="w3-container w3-panel  w3-card-2 w3-round-large" style="background-color: #FFF;">
                            <h2 class="w3-center w3-text-black w3-padding-32">Ads By Google Here...</h2>
                        </div>
                    </div>
         </div>
         <!---------------------End bottom Advertisement------------>
         
         
        <footer class="w3-container w3-Grey w3-center w3-large w3-margin-top" style="letter-spacing: 2px;">
           &nbsp;&nbsp;
        </footer>
        
        <script type='text/javascript' src='js/myscripts.js'></script>
        <script>
            function myFunction() {
                var x = document.getElementById("myTopnav");
                if (x.className === "topnav") {
                    x.className += " responsive";
                } else {
                    x.className = "topnav";
                }
            }
        </script>
    </body>
</html>